MessageHeader header        # 消息头信息

# 开关: true开, false关
bool enable   

# 亮度: 0-100 百分比   
uint8 brightness  